// ========== CONFIGURATION ==========
const API_URL = 'http://localhost:8000';
let currentLang = 'my';
let recognition = null;
let isRecording = false;
let synthesis = window.speechSynthesis;

// ========== INITIALIZATION ==========
document.addEventListener('DOMContentLoaded', () => {
    initSpeechRecognition();
    checkHealth();
    setTimeout(() => speak("မင်္ဂလာပါ! ကျွန်တော် TU AI Assistant ပါ။ တက္ကသိုလ်အကြောင်း ဘာမေးခွန်းမှန်း မေးလို့ရပါတယ်။"), 1000);
});

// ========== SPEECH RECOGNITION (STT) ==========
function initSpeechRecognition() {
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
        const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
        recognition = new SpeechRecognition();
        recognition.continuous = false;
        recognition.interimResults = false;
        recognition.lang = 'my-MM';

        recognition.onstart = () => {
            isRecording = true;
            document.getElementById('mic-btn').classList.add('recording');
            updateStatus('🎤 နားထောင်နေသည်... Listening...');
        };

        recognition.onresult = (event) => {
            const transcript = event.results[0][0].transcript;
            document.getElementById('text-input').value = transcript;
            sendMessage();
        };

        recognition.onerror = (event) => {
            console.error('Speech error:', event.error);
            updateStatus('❌ အသံမှတ်ယူမှု မအောင်မြင်ပါ - ထပ်မေးကြည့်ပါ');
            stopRecording();
        };

        recognition.onend = () => stopRecording();
    } else {
        updateStatus('⚠️ ဤဘရောက်ဇာတွင် အသံမှတ်ယူခြင်း မထောက်ပံ့ပါ');
        document.getElementById('mic-btn').style.display = 'none';
    }
}

function toggleSpeech() {
    if (!recognition) return;
    if (isRecording) recognition.stop();
    else {
        recognition.lang = currentLang === 'my' ? 'my-MM' : 'en-US';
        recognition.start();
    }
}

function stopRecording() {
    isRecording = false;
    document.getElementById('mic-btn').classList.remove('recording');
    updateStatus('🎤 အာ့ပါဆိုပါ - ခလုပ်နှိပ်ပြီး မေးခွန်းမေးပါ');
}

// ========== TEXT TO SPEECH (TTS) ==========
function speak(text) {
    synthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    const voices = synthesis.getVoices();
    const myanmarVoice = voices.find(v => v.lang.includes('my') || v.lang.includes('Myanmar'));
    const englishVoice = voices.find(v => v.lang.includes('en-US'));

    if (currentLang === 'my' && myanmarVoice) {
        utterance.voice = myanmarVoice;
        utterance.lang = 'my-MM';
    } else if (currentLang === 'en' && englishVoice) {
        utterance.voice = englishVoice;
        utterance.lang = 'en-US';
    } else {
        utterance.lang = currentLang === 'my' ? 'my-MM' : 'en-US';
    }

    utterance.rate = 0.9;
    utterance.pitch = 1;
    utterance.volume = 1;
    synthesis.speak(utterance);
}

speechSynthesis.onvoiceschanged = () => {
    console.log('Voices loaded:', speechSynthesis.getVoices().map(v => v.lang));
};

// ========== CHAT FUNCTIONS ==========
function setLanguage(lang) {
    currentLang = lang;
    document.getElementById('lang-my').classList.toggle('active', lang === 'my');
    document.getElementById('lang-en').classList.toggle('active', lang === 'en');
    const input = document.getElementById('text-input');
    input.placeholder = lang === 'my' ? 'ဒီမှာ ရိုက်ထည့်ပါ...' : 'Type here...';
    updateStatus(lang === 'my' ? 
        '🎤 အာ့ပါဆိုပါ - ခလုပ်နှိပ်ပြီး မေးခွန်းမေးပါ' : 
        '🎤 Press mic to ask');
}

function updateStatus(msg) {
    document.getElementById('status').textContent = msg;
}

function handleKeyPress(event) {
    if (event.key === 'Enter') sendMessage();
}

function quickAsk(question) {
    document.getElementById('text-input').value = question;
    sendMessage();
}

async function sendMessage() {
    const input = document.getElementById('text-input');
    const message = input.value.trim();
    if (!message) return;

    addMessage(message, 'user');
    input.value = '';
    document.getElementById('loading').classList.remove('hidden');

    try {
        const response = await fetch(`${API_URL}/chat`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                message: message,
                language: currentLang
            })
        });

        if (!response.ok) {
            const error = await response.json();
            throw new Error(error.detail || 'API Error');
        }

        const data = await response.json();
        console.log('Model used:', data.model_used);

        addMessage(data.response, 'bot', data.model_used);
        speak(data.response);

    } catch (error) {
        console.error('Error:', error);
        const errorMsg = currentLang === 'my' ? 
            'တောင်းပန်ပါတယ်၊ အဖြေရယူရန် မအောင်မြင်ပါ။ နောက်မှ ထပ်ကြိုးစားကြည့်ပါ။ (OpenRouter API စစ်ဆေးပါ)' :
            'Sorry, could not get response. Please check OpenRouter API key.';
        addMessage(errorMsg, 'bot');
        speak(errorMsg);
    } finally {
        document.getElementById('loading').classList.add('hidden');
    }
}

function addMessage(text, sender, modelInfo = '') {
    const container = document.getElementById('chat-container');
    const div = document.createElement('div');
    div.className = `message ${sender}-message`;

    const avatar = sender === 'bot' ? '🤖' : '👤';
    const isMyanmar = /[\u1000-\u109F]/.test(text);

    const modelBadge = sender === 'bot' && modelInfo ? 
        `<span style="font-size:11px; color:#aaa; display:block; margin-top:5px;">⚡ ${modelInfo}</span>` : '';

    div.innerHTML = `
        <div class="avatar">${avatar}</div>
        <div class="content">
            <p>${escapeHtml(text)}</p>
            ${modelBadge}
            ${isMyanmar && currentLang === 'en' ? '<p class="translation">(Myanmar text detected)</p>' : ''}
        </div>
    `;

    container.appendChild(div);
    container.scrollTop = container.scrollHeight;
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// ========== HEALTH CHECK ==========
async function checkHealth() {
    try {
        const res = await fetch(`${API_URL}/health`);
        const data = await res.json();
        console.log('Health:', data);

        if (data.openrouter_status === 'connected') {
            updateStatus('✅ OpenRouter connected - Region Free');
        } else {
            updateStatus('⚠️ OpenRouter API key စစ်ဆေးပါ');
        }
    } catch (e) {
        console.error('Backend not reachable');
        updateStatus('❌ Backend မရနိုင်ပါ - Server run ဟုတ်မဟုတ် စစ်ဆေးပါ');
    }
}

setInterval(checkHealth, 30000);
