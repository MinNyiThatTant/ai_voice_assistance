# 🎓 TU Voice AI Assistant
## Technological University Voice-Enabled AI Assistant

Laptop တစ်လုံးတည်းနဲ့ run ရုံ - အခမဲ့ tools တွေသုံးထားတယ်။

---

## 🚀 အဆင့်ဆင့် Run မယ်

### Step 1: Python Environment ဖန်တီးပါ
```bash
# Install Python 3.10+ if not installed
python --version

# Create virtual environment
python -m venv venv

# Activate (Windows)
venv\Scripts\activate

# Activate (Mac/Linux)
source venv/bin/activate
```

### Step 2: Dependencies Install လုပ်ပါ
```bash
pip install -r requirements.txt --default-timeout=1000 -i https://pypi.tuna.tsinghua.edu.cn/simple
```

### Step 3: OpenRouter API Key ရယူပါ
1. https://openrouter.ai/keys သွားပါ
2. "Sign In" နှိပ်ပြီး Google account (သို့) Email နဲ့ sign up လုပ်ပါ
3. Credit card မလိုပါဘူး - အခမဲ့ပါ
4. "Create Key" နှိပ်ပြီး key name ရေးပါ
5. Key ကို copy ယူပြီး `.env` file ထဲမှာ paste လုပ်ပါ

### Step 4: Run the Backend
```bash
uvicorn main:app --reload --host 0.0.0.0 --port 8000
```

### Step 5: Browser မှာ ဖွင့်ပါ
```
http://localhost:8000/static/index.html
```

---

## 🎯 အသုံးပြုပုံ

1. **🎤 Mic button** နှိပ်ပြီး မြန်မာလို မေးခွန်းမေးပါ
2. **⌨️** (သို့) Text box မှာ ရိုက်ထည့်ပြီး Enter နှိပ်ပါ
3. **🤖** AI က မြန်မာလို အသံထွက်ပြီး ဖြေပေးမယ်
4. **Quick Buttons** မှာ အမြန်မေးခွန်းများ ရွေးချယ်နိုင်

---

## 🛠️ Architecture

```
┌─────────────────┐     ┌──────────────────┐     ┌─────────────────┐
│   Browser UI    │────▶│   FastAPI Backend │────▶│  ChromaDB (RAG) │
│  (Voice + Text) │     │   (Python)        │     │  Knowledge Base │
└─────────────────┘     └──────────────────┘     └─────────────────┘
         │                       │
         │                       ▼
         │              ┌──────────────────┐
         │              │  OpenRouter API   │
         │              │  (Free LLM API)   │
         │              │  Region Free ✅    │
         │              └──────────────────┘
         ▼
┌─────────────────────────────────────────┐
│  Web Speech API (Free - Browser Built-in)│
│  - STT: Speech-to-Text (Myanmar)        │
│  - TTS: Text-to-Speech (Myanmar voice)  │
└─────────────────────────────────────────┘
```

---

## 📚 Knowledge Base Documents

| File | Content |
|------|---------|
| `admission.md` | ဝင်ရောက်ရန် လိုအပ်ချက်များ |
| `departments.md` | ဌာနများနှင့် သင်တန်းများ |
| `fees.md` | ကျောင်းလခနှင့် အခကြေးငွေများ |
| `scholarships.md` | ပညာသင်ဆုများ |
| `hostel.md` | အိပ်ရာခန်းနှင့် နေရာ |
| `curriculum.md` | ပါဠိစနစ် |
| `faq.md` | အမြဲမေးလေ့ရှိသော မေးခွန်းများ |

**Knowledge base ကို update လုပ်ချင်ရင်:**
- `.md` files တွေ edit လုပ်ပါ
- `chroma_db` folder ဖျက်ပြီး
- App ကို restart လုပ်ပါ (auto-reload)

---

## 💡 အကြံပေးချက်များ

### Myanmar Voice အတွက် Best Browser:
- **Google Chrome** (Windows/Mac/Linux) - Myanmar voice support အကောင်းဆုံး
- **Microsoft Edge** - Windows မှာ အဆင်ပြေ
- **Firefox** - အနည်းငယ် ကန့်သတ်ချက်ရှိ

### Performance အဆင်ပြေစေဖို့:
- Laptop မှာ **8GB RAM** အနည်းဆုံး လိုအပ်
- **SSD** ပေါ်မှာ run ရင် ChromaDB ပိုမြန်
- ပထမဆုံး run ရင် model download လုပ်ရတာ ၅မိနစ်ခန့် ကြာနိုင်

---

## 🔧 Troubleshooting

| ပြဿနာ | ဖြေရှင်းနည်း |
|--------|-------------|
| pip install timeout | `--default-timeout=1000 -i https://pypi.tuna.tsinghua.edu.cn/simple` သုံး |
| Myanmar voice မထွက်ဘူး | Chrome browser သုံးပါ၊ Settings > Languages > Myanmar add လုပ်ပါ |
| API Key error | `.env` file မှာ OPENROUTER_API_KEY စစ်ပါ |
| ChromaDB error | `chroma_db` folder ဖျက်ပြီး restart လုပ်ပါ |
| Slow response | Internet speed စစ်ပါ |

---

## 📄 License
MIT License - အခမဲ့ သုံးစွဲနိုင်ပါသည်
