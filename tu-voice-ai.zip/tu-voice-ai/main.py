from fastapi import FastAPI, HTTPException
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import os
import requests
from dotenv import load_dotenv
from rag_engine import get_knowledge_base

# ========== LOAD ENVIRONMENT ==========
load_dotenv()

# ========== CONFIGURATION ==========
OPENROUTER_API_KEY = os.getenv("OPENROUTER_API_KEY", "YOUR_OPENROUTER_API_KEY_HERE")
OPENROUTER_URL = "https://openrouter.ai/api/v1/chat/completions"
DEFAULT_MODEL = "deepseek/deepseek-chat:free"

FALLBACK_MODELS = [
    "meta-llama/llama-4-scout:free",
    "google/gemma-3-27b-it:free",
    "mistralai/mistral-small-3.1-24b-instruct:free"
]

# ========== FASTAPI APP ==========
app = FastAPI(title="TU Voice AI Assistant - Myanmar")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.mount("/static", StaticFiles(directory="static"), name="static")

# ========== STARTUP ==========
@app.on_event("startup")
async def startup_event():
    get_knowledge_base()
    print("✅ Knowledge base loaded!")
    print("🚀 OpenRouter API ready (no region restriction)")

# ========== DATA MODELS ==========
class ChatRequest(BaseModel):
    message: str
    language: str = "my"

class ChatResponse(BaseModel):
    response: str
    sources: list
    model_used: str = ""

# ========== SYSTEM PROMPT ==========
SYSTEM_PROMPT = """You are a helpful and friendly assistant for Technological University in Myanmar. 
You help students, especially new first-year students, with questions about:
- Admission process and requirements
- University fees and payments
- Available departments and programs
- Scholarships and financial aid
- Hostel accommodation
- Academic curriculum and rules
- Campus life and facilities

IMPORTANT RULES:
1. Always answer in the SAME LANGUAGE as the user's question
2. If the user asks in Myanmar/Burmese, answer in Myanmar/Burmese
3. If the user asks in English, answer in English
4. Use natural, conversational tone
5. Be accurate - only use the provided context
6. If you don't know the answer, say so honestly
7. Keep answers concise but complete (2-4 paragraphs max)
8. Use Myanmar numbers (၁, ၂, ၃) when writing in Myanmar
9. Be friendly and encouraging to new students

Current conversation context:
"""

# ========== LLM API CALL ==========
def call_openrouter(prompt: str, model: str = DEFAULT_MODEL) -> tuple:
    headers = {
        "Authorization": f"Bearer {OPENROUTER_API_KEY}",
        "Content-Type": "application/json",
        "HTTP-Referer": "http://localhost:8000",
        "X-Title": "TU Voice AI Assistant"
    }

    data = {
        "model": model,
        "messages": [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": prompt}
        ],
        "max_tokens": 800,
        "temperature": 0.3
    }

    try:
        response = requests.post(
            OPENROUTER_URL,
            headers=headers,
            json=data,
            timeout=30
        )

        if response.status_code == 200:
            result = response.json()
            return result["choices"][0]["message"]["content"], model
        elif response.status_code == 429:
            print(f"⚠️ Rate limit on {model}, trying fallback...")
            return None, model
        else:
            print(f"⚠️ Error {response.status_code}: {response.text}")
            return None, model
    except Exception as e:
        print(f"⚠️ API Error: {e}")
        return None, model

def get_llm_response(prompt: str) -> tuple:
    result, model = call_openrouter(prompt, DEFAULT_MODEL)
    if result:
        return result, model

    for fallback in FALLBACK_MODELS:
        print(f"🔄 Trying fallback: {fallback}")
        result, model = call_openrouter(prompt, fallback)
        if result:
            return result, model

    return None, "all_failed"

# ========== API ENDPOINTS ==========
@app.get("/")
async def root():
    return {
        "message": "TU Voice AI Assistant API (OpenRouter)",
        "status": "running",
        "region_free": True
    }

@app.post("/chat", response_model=ChatResponse)
async def chat(request: ChatRequest):
    try:
        kb = get_knowledge_base()
        context = kb.get_context(request.message)

        language_instruction = "Please answer in Myanmar language" if request.language == "my" else "Please answer in English"
        full_prompt = f"{context}\n\nUser question: {request.message}\n\n{language_instruction}:"

        response_text, model_used = get_llm_response(full_prompt)

        if not response_text:
            raise HTTPException(
                status_code=503,
                detail="All LLM models unavailable. Please try again later."
            )

        sources = kb.query(request.message, n_results=2)
        source_list = [s["source"] for s in sources]

        return ChatResponse(
            response=response_text,
            sources=list(set(source_list)),
            model_used=model_used
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/health")
async def health_check():
    kb = get_knowledge_base()
    kb_count = kb.collection.count() if kb.collection else 0

    try:
        headers = {"Authorization": f"Bearer {OPENROUTER_API_KEY}"}
        test = requests.get("https://openrouter.ai/api/v1/auth/key", headers=headers, timeout=5)
        api_status = "connected" if test.status_code == 200 else "error"
    except:
        api_status = "unreachable"

    return {
        "status": "healthy",
        "kb_loaded": kb_count > 0,
        "kb_documents": kb_count,
        "openrouter_status": api_status,
        "region_free": True
    }

@app.get("/models")
async def list_models():
    return {
        "primary": DEFAULT_MODEL,
        "fallbacks": FALLBACK_MODELS,
        "all_free_models": [
            "deepseek/deepseek-chat:free",
            "deepseek/deepseek-r1:free",
            "meta-llama/llama-4-scout:free",
            "meta-llama/llama-4-maverick:free",
            "google/gemma-3-27b-it:free",
            "mistralai/mistral-small-3.1-24b-instruct:free",
            "qwen/qwen3-235b-a22b:free"
        ]
    }
