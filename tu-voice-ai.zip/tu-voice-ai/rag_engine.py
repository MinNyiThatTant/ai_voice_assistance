import os
import chromadb
from sentence_transformers import SentenceTransformer
from typing import List, Dict
import glob

class TUKnowledgeBase:
    def __init__(self, db_path: str = "./chroma_db"):
        self.client = chromadb.PersistentClient(path=db_path)
        self.collection = self.client.get_or_create_collection(
            name="tu_knowledge",
            metadata={"hnsw:space": "cosine"}
        )
        self.encoder = SentenceTransformer('sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2')
        self.knowledge_dir = "./knowledge_base"

    def load_documents(self):
        if self.collection.count() > 0:
            print(f"Knowledge base already loaded ({self.collection.count()} documents)")
            return

        files = glob.glob(os.path.join(self.knowledge_dir, "*.md"))

        for idx, file_path in enumerate(files):
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()

            chunks = self._chunk_text(content)

            for chunk_idx, chunk in enumerate(chunks):
                chunk_id = f"{os.path.basename(file_path)}_{idx}_{chunk_idx}"
                self.collection.add(
                    ids=[chunk_id],
                    documents=[chunk],
                    metadatas=[{"source": os.path.basename(file_path)}]
                )

        print(f"Loaded {self.collection.count()} document chunks into knowledge base")

    def _chunk_text(self, text: str, max_chars: int = 800) -> List[str]:
        paragraphs = text.split('\n\n')
        chunks = []
        current_chunk = ""

        for para in paragraphs:
            if len(current_chunk) + len(para) < max_chars:
                current_chunk += para + "\n\n"
            else:
                if current_chunk:
                    chunks.append(current_chunk.strip())
                current_chunk = para + "\n\n"

        if current_chunk:
            chunks.append(current_chunk.strip())

        return chunks if chunks else [text]

    def query(self, question: str, n_results: int = 3) -> List[Dict]:
        query_embedding = self.encoder.encode(question).tolist()

        results = self.collection.query(
            query_embeddings=[query_embedding],
            n_results=n_results,
            include=["documents", "metadatas", "distances"]
        )

        documents = []
        for i in range(len(results['documents'][0])):
            documents.append({
                'text': results['documents'][0][i],
                'source': results['metadatas'][0][i]['source'],
                'distance': results['distances'][0][i]
            })

        return documents

    def get_context(self, question: str) -> str:
        docs = self.query(question)
        context = "Relevant university information:\n\n"
        for i, doc in enumerate(docs, 1):
            context += f"[{i}] From {doc['source']}:\n{doc['text']}\n\n"
        return context

_kb = None

def get_knowledge_base():
    global _kb
    if _kb is None:
        _kb = TUKnowledgeBase()
        _kb.load_documents()
    return _kb
