# Frequently Asked Questions

## Q: Can I change my major after first year?
A: Yes, but very difficult. Must have GPA > 4.0 and target department must have space. Must apply within first 2 weeks of second year.

## Q: What laptop do I need?
A: Minimum: Intel i5 or AMD Ryzen 5, 8GB RAM, 256GB SSD. Recommended for Computer/Electronic: 16GB RAM, dedicated GPU. All engineering students need laptops for CAD software.

## Q: Is there WiFi on campus?
A: Yes, free campus WiFi in library and all labs. Hostel has WiFi until 11 PM. Speed is 10 Mbps shared.

## Q: Can I work part-time while studying?
A: Yes, but maximum 20 hours/week. University recommends work-study program instead of outside jobs.

## Q: What happens if I fail a subject?
A: Can retake exam in next semester. Maximum 2 retakes. If still fail, must repeat the year.

## Q: Are there student clubs?
A: Yes: Engineering Club, Robotics Club, Programming Club, English Club, Sports Club, Music Club. Join during first month.

## Q: How to get internship?
A: Career Center helps arrange. Usually 3rd and 4th year. Some companies: Yatanarpon, MPT, Ooredoo, construction companies.

## Q: Can foreign students apply?
A: Yes, but must have equivalent qualifications and student visa. Contact International Office.

## Q: What is the dress code?
A: Uniform required: White shirt, dark blue longyi/pants for boys. White blouse, dark blue htamein for girls. Wednesday: traditional dress day.

## Q: Is there a gym or sports facility?
A: Yes, free gym, basketball court, football field, badminton court. Open 6 AM - 8 PM.

## Q: How to access library?
A: Student ID required. Open 8 AM - 8 PM. Can borrow 5 books for 2 weeks. Digital library available online.

## Q: What software do we use?
A: AutoCAD, MATLAB, Python, Microsoft Office (free for students), SolidWorks, ETABS, various programming IDEs.
