# Academic Curriculum and Structure

## Degree Structure
- Total duration: 5 years (10 semesters)
- Credit system: 180 total credits required
- Each semester: 18-20 credits
- Minimum GPA to graduate: 2.0

## First Year (Foundation)
- Common courses for all students
- Subjects: Mathematics, Physics, Chemistry, English, Myanmar, Basic Engineering Drawing, Computer Fundamentals
- No specialization yet

## Second Year
- Introduction to chosen department
- Basic engineering courses
- Lab work begins

## Third Year
- Core technical courses
- First industrial training (6 weeks during summer)
- Mini project

## Fourth Year
- Advanced courses
- Second industrial training (8 weeks)
- Research methodology course

## Fifth Year (Final Year)
- Major project/thesis (full year)
- Elective courses
- Professional practice
- Final examination

## Grading System
- A+ = 5.0 (90-100%)
- A = 4.5 (80-89%)
- B+ = 4.0 (70-79%)
- B = 3.5 (60-69%)
- C+ = 3.0 (55-59%)
- C = 2.5 (50-54%)
- D = 2.0 (40-49%)
- F = 0.0 (below 40%)

## Important Rules
- Maximum 3 F grades allowed (must retake)
- Attendance minimum: 75% per subject
- Must complete all industrial training
- Final project must be defended in front of panel
