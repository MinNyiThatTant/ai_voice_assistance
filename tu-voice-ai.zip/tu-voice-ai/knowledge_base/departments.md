# Technological University Departments

## Engineering Departments
1. **Civil Engineering** - 5 years, B.E. (Civil)
   - Focus: Structural design, construction, infrastructure
   - Labs: Structural lab, concrete lab, surveying lab

2. **Mechanical Engineering** - 5 years, B.E. (Mechanical)
   - Focus: Thermodynamics, machine design, manufacturing
   - Labs: Heat engine lab, CNC lab, fluid mechanics lab

3. **Electrical Engineering** - 5 years, B.E. (Electrical)
   - Focus: Power systems, electronics, control systems
   - Labs: Power lab, electronics lab, PLC lab

4. **Electronic Engineering** - 5 years, B.E. (Electronic)
   - Focus: Communication systems, embedded systems, VLSI
   - Labs: Communication lab, microprocessor lab, PCB lab

5. **Computer Engineering** - 5 years, B.E. (Computer)
   - Focus: Software, hardware, networking, AI
   - Labs: Computer lab, network lab, IoT lab

6. **Chemical Engineering** - 5 years, B.E. (Chemical)
   - Focus: Process design, petrochemicals, environmental
   - Labs: Process control lab, chemical analysis lab

7. **Mining Engineering** - 5 years, B.E. (Mining)
   - Focus: Mineral extraction, mine safety, geology
   - Labs: Rock mechanics lab, mineral processing lab

8. **Petroleum Engineering** - 5 years, B.E. (Petroleum)
   - Focus: Oil & gas extraction, reservoir engineering
   - Labs: Drilling simulator, reservoir lab

## Architecture Department
- 5 years, B.Arch
- Focus: Building design, urban planning, sustainable design
- Labs: Design studio, model making lab

## Supporting Departments
- Mathematics Department
- Physics Department  
- Chemistry Department
- English Department
- Myanmar Department

## Department Selection
- Students choose major after first year (common foundation)
- Based on first year GPA and department capacity
- Top GPA students get first choice priority
