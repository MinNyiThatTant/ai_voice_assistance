# Scholarships and Financial Aid

## Government Scholarships
1. **State Scholarship** - Full tuition + monthly stipend
   - Requirements: Top 10% of class GPA
   - Amount: 100,000 MMK/month + free tuition
   - Duration: Until graduation (maintain GPA > 4.0)

2. **Ministry Scholarship** - Full tuition only
   - Requirements: GPA > 3.5
   - Covers all tuition and lab fees

3. **Ethnic Minority Scholarship** - Partial support
   - Requirements: Valid ethnic minority ID
   - Amount: 50% tuition reduction

## University Scholarships
1. **Rector's Award** - 200,000 MMK one-time
   - Top student of each department
   - Based on final year project

2. **Department Excellence** - 100,000 MMK
   - Best academic performance per year

## External Scholarships
- JICA Scholarship (Japan)
- KOICA Scholarship (Korea)  
- Erasmus Mundus (Europe)
- ASEAN Scholarship

## How to Apply
- Submit application to Scholarship Office (Room 205)
- Deadline: October 1 each year
- Required: GPA transcript, recommendation letters, essay
- Interview may be required

## Work-Study Program
- Library assistant: 20 hours/week, 80,000 MMK/month
- Lab assistant: 15 hours/week, 100,000 MMK/month
- Teaching assistant (3rd year+): 60,000 MMK/month
