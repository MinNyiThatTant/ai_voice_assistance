# University Fees and Financial Information

## Tuition Fees (Per Semester)
- Engineering programs: 50,000 MMK per semester
- Architecture program: 60,000 MMK per semester
- Examination fees: 10,000 MMK per semester
- Lab fees: 15,000 MMK per semester

## Other Fees
- Registration fee (one-time): 25,000 MMK
- Library fee: 5,000 MMK per year
- Student ID card: 3,000 MMK
- Insurance: 5,000 MMK per year

## Total First Year Estimate
- Tuition: 100,000 MMK (2 semesters)
- Registration: 25,000 MMK
- Labs: 30,000 MMK
- Others: 20,000 MMK
- **Total: ~175,000 MMK for first year**

## Payment Methods
- Cash at university cashier office
- KBZ Pay (mobile banking)
- CB Bank transfer
- Must pay before registration deadline

## Late Payment
- Late fee: 5,000 MMK per week
- Maximum 2 weeks late allowed
- After 2 weeks, must reapply for admission
