# Technological University Admission Guide

## First Year Admission Requirements
- Must pass Matriculation Exam (or equivalent) with Science stream
- Minimum marks: Physics, Chemistry, Mathematics, English
- Must apply through Online Admission System (MOE website)
- Application period: Usually June-July each year

## Required Documents
1. Matriculation Exam Mark Sheet (original + copy)
2. National ID Card (or student ID)
3. Passport-size photos (4 copies)
4. Recommendation letter from high school principal
5. Township recommendation (for scholarship priority)

## Entrance Exam
- Some departments may require additional entrance exam
- Exam subjects: Mathematics, Physics, English
- Date announced on university website

## Important Dates 2026-2027
- Application opens: June 15, 2026
- Application deadline: July 30, 2026
- Entrance exam: August 15, 2026
- Results announcement: September 1, 2026
- Registration: September 10-20, 2026
- First day of class: October 1, 2026

## Contact
- Admission Office: Room 101, Main Building
- Phone: 01-XXXXXX
- Email: admission@tu.edu.mm
- Office hours: 9:00 AM - 3:00 PM (Mon-Fri)
