# Hostel and Accommodation

## University Hostel
- Location: Campus east wing
- Rooms: 4 students per room
- Facilities: Bed, desk, wardrobe, shared bathroom
- Common areas: Study room, TV room, dining hall

## Hostel Fees
- Room rent: 20,000 MMK per month
- Meal plan: 150,000 MMK per month (3 meals)
- Utilities included in rent
- Security deposit: 50,000 MMK (refundable)

## Hostel Rules
- Gate closes at 9:00 PM
- Visitors allowed only in common areas (until 6 PM)
- No alcohol, no smoking
- Monthly room inspection
- Must maintain minimum GPA to stay

## Application
- Apply during admission period
- Priority: Students from outside Yangon/Mandalay
- Required: Parents' consent letter, local guardian contact
- Waiting list if full

## Off-Campus Housing
- Nearby apartments: 100,000-200,000 MMK/month
- Shared rooms: 50,000-80,000 MMK/month
- Recommended areas: University quarter, Hlaing Township
- Many students share apartments in groups of 3-4

## Transportation
- University bus: Free (campus to main gate)
- Public bus: 200-500 MMK per ride
- Motorbike taxi: 1,000-2,000 MMK per ride
